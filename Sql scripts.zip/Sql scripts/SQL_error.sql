﻿USE AdventureWorks2012
GO

CREATE TABLE Test (a INT PRIMARY KEY, b int primary key)